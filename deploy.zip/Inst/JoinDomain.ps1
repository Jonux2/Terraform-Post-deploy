# Logea la ejecucion del script
$logFilePath = "C:\Inst\Scrip2_Deploy.txt"
Start-Transcript -Path $logFilePath -Append

# Une a dominio la VM
`$DomainName = "dominio.local"
`$Username = "join.domain"
`$Password = "clavesegura"
`$Credential = New-Object System.Management.Automation.PSCredential (`$Username, (ConvertTo-SecureString -String `$Password -AsPlainText -Force))
Add-Computer -DomainName `$DomainName -Credential `$Credential -Force -Restart

# Elimina la tarea programada
`$TaskName = "JoinDomainAfterReboot"
Unregister-ScheduledTask -TaskName `$TaskName -Confirm:`$false

# Elimina el archivo Script2_JoinDomain.ps1
$DeployPath = "c:\Deploy"
Remove-Item -Path $DeployPath -Recurse -Force

Restart-Computer -Force
Stop-Transcript